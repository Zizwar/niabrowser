import React from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Icon } from 'react-native-elements';

const BottomSheet = ({ 
  visible, 
  onClose, 
  isDarkMode, 
  toggleDarkMode, 
  setUrl, 
  toggleDesktopMode, 
  isDesktopMode, 
  shareUrl, 
  openDevTools,
  openHistory,
  openCrudModal,
  getSourceHtml,
  clearData,
  openAboutModal,
  openScriptManager,
  currentUrl
}) => {
  const backgroundColor = isDarkMode ? '#1E1E1E' : '#FFFFFF';
  const textColor = isDarkMode ? '#FFFFFF' : '#000000';

  const BottomSheetItem = ({ icon, title, onPress }) => (
    <TouchableOpacity style={styles.item} onPress={onPress}>
      <Icon name={icon} type="material" color="#007AFF" size={24} />
      <Text style={[styles.itemText, { color: textColor }]}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <TouchableOpacity
        style={styles.overlay}
        activeOpacity={1}
        onPress={onClose}
      >
        <View style={[styles.bottomSheetContainer, { backgroundColor }]}>
          <ScrollView>
            <BottomSheetItem icon="history" title="History" onPress={openHistory} />
            <BottomSheetItem icon="home" title="Home" onPress={() => {
              setUrl('https://www.google.com');
              onClose();
            }} />
            <BottomSheetItem
              icon={isDarkMode ? "brightness-7" : "brightness-2"}
              title={isDarkMode ? "Light mode" : "Dark mode"}
              onPress={toggleDarkMode}
            />
            <BottomSheetItem
              icon="desktop-windows"
              title={isDesktopMode ? "Mobile view" : "Desktop view"}
              onPress={toggleDesktopMode}
            />
            <BottomSheetItem icon="share" title="Share" onPress={() => shareUrl(currentUrl)} />
            <BottomSheetItem icon="developer-mode" title="DevTools" onPress={() => {
              openDevTools();
              onClose();
            }} />
            <BottomSheetItem icon="build" title="CRUD" onPress={() => {
              openCrudModal();
              onClose();
            }} />
            <BottomSheetItem icon="code" title="View Source" onPress={() => {
              getSourceHtml();
              onClose();
            }} />
            <BottomSheetItem icon="extension" title="Script Manager" onPress={() => {
              openScriptManager();
              onClose();
            }} />
            <BottomSheetItem icon="delete" title="Clear Data" onPress={clearData} />
            <BottomSheetItem icon="info" title="About" onPress={() => {
              openAboutModal();
              onClose();
            }} />
          </ScrollView>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};


const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  bottomSheetContainer: {
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '80%',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
  },
  itemText: {
    marginLeft: 15,
    fontSize: 16,
  },
});

export default BottomSheet;